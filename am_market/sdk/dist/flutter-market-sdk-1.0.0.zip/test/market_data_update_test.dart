//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:am_market_client/api.dart';
import 'package:test/test.dart';

// tests for MarketDataUpdate
void main() {
  // final instance = MarketDataUpdate();

  group('test MarketDataUpdate', () {
    // int timestamp
    test('to test the property `timestamp`', () async {
      // TODO
    });

    // Map<String, QuoteChange> quotes (default value: const {})
    test('to test the property `quotes`', () async {
      // TODO
    });


  });

}
